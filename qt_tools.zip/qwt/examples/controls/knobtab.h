#ifndef _KNOB_TAB_H
#define _KNOB_TAB_H 1

#include <qwidget.h>

class KnobTab: public QWidget
{
public:
    KnobTab( QWidget *parent = NULL );
};

#endif
