#include "sysparam.h"

SysParam::SysParam()
{
}
